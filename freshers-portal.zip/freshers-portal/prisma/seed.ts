import { PrismaClient, EventCategory, DayOfWeek } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

function daysFromNow(days: number, hour = 10, minute = 0) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  d.setHours(hour, minute, 0, 0);
  return d;
}

async function main() {
  console.log('Seeding database...');

  // ---------- Clean existing data (dev only) ----------
  await prisma.chatMessage.deleteMany();
  await prisma.chatSession.deleteMany();
  await prisma.registrationSubmission.deleteMany();
  await prisma.timetableEntry.deleteMany();
  await prisma.eventRegistration.deleteMany();
  await prisma.event.deleteMany();
  await prisma.club.deleteMany();
  await prisma.faculty.deleteMany();
  await prisma.session.deleteMany();
  await prisma.account.deleteMany();
  await prisma.user.deleteMany();

  // ---------- Users ----------
  const hashedPassword = await bcrypt.hash('password123', 10);

  const student = await prisma.user.create({
    data: {
      name: 'Alex Student',
      email: 'alex.student@college.edu',
      password: hashedPassword,
      role: 'STUDENT',
      department: 'Computer Science',
      year: 1,
      rollNumber: '25CS1042',
    },
  });

  await prisma.user.create({
    data: {
      name: 'Priya Sharma',
      email: 'priya.sharma@college.edu',
      password: hashedPassword,
      role: 'STUDENT',
      department: 'Electronics',
      year: 1,
      rollNumber: '25EC1108',
    },
  });

  // ---------- Clubs ----------
  const codingClub = await prisma.club.create({
    data: {
      name: 'Coding Club',
      category: 'Technical',
      description:
        'A community of student developers building projects, competing in hackathons, and hosting weekly coding workshops for all skill levels.',
      meetingTime: 'Every Friday, 5:00 PM',
      meetingVenue: 'CS Lab 3',
      contactEmail: 'codingclub@college.edu',
      memberCount: 142,
    },
  });

  const dramaClub = await prisma.club.create({
    data: {
      name: 'Drama Club',
      category: 'Cultural',
      description:
        'Stage plays, improv nights, and script-writing workshops. No experience needed — just bring your enthusiasm!',
      meetingTime: 'Every Wednesday, 6:00 PM',
      meetingVenue: 'Auditorium Green Room',
      contactEmail: 'dramaclub@college.edu',
      memberCount: 68,
    },
  });

  const sportsClub = await prisma.club.create({
    data: {
      name: 'Sports Club',
      category: 'Sports',
      description: 'Football, basketball, badminton, and athletics. Inter-college tournaments and daily practice sessions.',
      meetingTime: 'Daily, 6:00 AM',
      meetingVenue: 'Sports Complex',
      contactEmail: 'sports@college.edu',
      memberCount: 210,
    },
  });

  const musicClub = await prisma.club.create({
    data: {
      name: 'Music Society',
      category: 'Music',
      description: 'Bands, solo acts, and jam sessions. Open mic every month and annual battle of the bands.',
      meetingTime: 'Every Tuesday, 7:00 PM',
      meetingVenue: 'Music Room, Student Center',
      contactEmail: 'music@college.edu',
      memberCount: 55,
    },
  });

  const literaryClub = await prisma.club.create({
    data: {
      name: 'Literary Circle',
      category: 'Literary',
      description: 'Book discussions, poetry slams, and the annual campus literary magazine.',
      meetingTime: 'Every 2nd Saturday, 4:00 PM',
      meetingVenue: 'Library Seminar Hall',
      contactEmail: 'literary@college.edu',
      memberCount: 40,
    },
  });

  const artsClub = await prisma.club.create({
    data: {
      name: 'Fine Arts Club',
      category: 'Arts',
      description: 'Painting, sketching, and design workshops, plus the annual campus art exhibition.',
      meetingTime: 'Every Thursday, 5:30 PM',
      meetingVenue: 'Art Studio, Block D',
      contactEmail: 'arts@college.edu',
      memberCount: 33,
    },
  });

  // ---------- Events ----------
  await prisma.event.create({
    data: {
      title: 'Freshers Welcome Party',
      description:
        "Kick off your college journey with music, games, food stalls, and a chance to meet your batchmates and seniors. Dress code: casual and colorful!",
      category: EventCategory.WELCOME,
      venue: 'Main Auditorium Lawn',
      startTime: daysFromNow(14, 18, 0),
      endTime: daysFromNow(14, 22, 0),
      isFeatured: true,
      capacity: 500,
    },
  });

  await prisma.event.create({
    data: {
      title: 'Intro to Web Development Workshop',
      description: 'Hands-on workshop covering HTML, CSS, and JavaScript basics. Laptops required. Beginners welcome!',
      category: EventCategory.WORKSHOP,
      venue: 'CS Lab 3',
      startTime: daysFromNow(3, 15, 0),
      endTime: daysFromNow(3, 17, 30),
      clubId: codingClub.id,
      capacity: 40,
    },
  });

  await prisma.event.create({
    data: {
      title: 'Hackathon: Code for Campus',
      description: '24-hour hackathon to build tools that improve campus life. Prizes for top 3 teams.',
      category: EventCategory.TECHNICAL,
      venue: 'Innovation Center',
      startTime: daysFromNow(20, 9, 0),
      endTime: daysFromNow(21, 9, 0),
      clubId: codingClub.id,
      capacity: 100,
    },
  });

  await prisma.event.create({
    data: {
      title: 'Open Mic Night',
      description: 'Poetry, music, comedy — sign up to perform or just come enjoy the show.',
      category: EventCategory.CULTURAL,
      venue: 'Student Center Amphitheatre',
      startTime: daysFromNow(6, 19, 0),
      endTime: daysFromNow(6, 21, 30),
      clubId: musicClub.id,
      capacity: 150,
    },
  });

  await prisma.event.create({
    data: {
      title: 'Drama Club Auditions',
      description: 'Auditions for the annual autumn production. All years welcome.',
      category: EventCategory.CLUB_MEETING,
      venue: 'Auditorium Green Room',
      startTime: daysFromNow(5, 16, 0),
      endTime: daysFromNow(5, 18, 0),
      clubId: dramaClub.id,
      capacity: 60,
    },
  });

  await prisma.event.create({
    data: {
      title: 'Inter-Department Football Tournament',
      description: 'Cheer on your department team in the annual football championship.',
      category: EventCategory.SPORTS,
      venue: 'Sports Complex',
      startTime: daysFromNow(10, 16, 0),
      endTime: daysFromNow(10, 19, 0),
      clubId: sportsClub.id,
    },
  });

  await prisma.event.create({
    data: {
      title: 'Mid-Semester Exams Begin',
      description: 'First round of mid-semester examinations for all first-year courses. Check your timetable for slots.',
      category: EventCategory.EXAM,
      venue: 'Examination Hall A & B',
      startTime: daysFromNow(30, 9, 0),
      endTime: daysFromNow(35, 17, 0),
    },
  });

  await prisma.event.create({
    data: {
      title: 'Independence Day Holiday',
      description: 'Campus closed for the national holiday.',
      category: EventCategory.HOLIDAY,
      venue: 'Campus-wide',
      startTime: daysFromNow(25, 0, 0),
      endTime: daysFromNow(25, 23, 59),
    },
  });

  await prisma.event.create({
    data: {
      title: 'Literary Circle: Poetry Slam',
      description: 'An evening of spoken word and poetry from students across departments.',
      category: EventCategory.CULTURAL,
      venue: 'Library Seminar Hall',
      startTime: daysFromNow(12, 17, 0),
      endTime: daysFromNow(12, 19, 0),
      clubId: literaryClub.id,
      capacity: 80,
    },
  });

  await prisma.event.create({
    data: {
      title: 'Campus Art Exhibition',
      description: 'Showcasing student paintings, sketches, and digital art from the semester.',
      category: EventCategory.CULTURAL,
      venue: 'Art Studio, Block D',
      startTime: daysFromNow(18, 11, 0),
      endTime: daysFromNow(18, 17, 0),
      clubId: artsClub.id,
    },
  });

  // ---------- Faculty ----------
  await prisma.faculty.createMany({
    data: [
      {
        name: 'Dr. Anjali Rao',
        department: 'Computer Science',
        designation: 'Associate Professor',
        email: 'anjali.rao@college.edu',
        phone: '+91 44 2345 6001',
        officeRoom: 'CS Block, Room 214',
        officeHours: 'Mon & Wed, 2:00–4:00 PM',
        bio: 'Specializes in machine learning and distributed systems.',
      },
      {
        name: 'Dr. Karthik Iyer',
        department: 'Computer Science',
        designation: 'Assistant Professor',
        email: 'karthik.iyer@college.edu',
        phone: '+91 44 2345 6002',
        officeRoom: 'CS Block, Room 118',
        officeHours: 'Tue & Thu, 10:00 AM–12:00 PM',
        bio: 'Teaches data structures and algorithms; research in computer vision.',
      },
      {
        name: 'Prof. Meera Nair',
        department: 'Electronics',
        designation: 'Professor & Head of Department',
        email: 'meera.nair@college.edu',
        phone: '+91 44 2345 6101',
        officeRoom: 'ECE Block, Room 301',
        officeHours: 'Mon–Fri, by appointment',
        bio: 'Leads research in embedded systems and IoT.',
      },
      {
        name: 'Dr. Vivek Menon',
        department: 'Electronics',
        designation: 'Assistant Professor',
        email: 'vivek.menon@college.edu',
        officeRoom: 'ECE Block, Room 205',
        officeHours: 'Wed & Fri, 1:00–3:00 PM',
      },
      {
        name: 'Dr. Fatima Sheikh',
        department: 'Mathematics',
        designation: 'Associate Professor',
        email: 'fatima.sheikh@college.edu',
        officeRoom: 'Science Block, Room 110',
        officeHours: 'Mon, Wed & Fri, 11:00 AM–1:00 PM',
        bio: 'Teaches calculus and discrete mathematics for first-years.',
      },
      {
        name: 'Prof. Ramesh Pillai',
        department: 'Mechanical Engineering',
        designation: 'Professor',
        email: 'ramesh.pillai@college.edu',
        officeRoom: 'Mech Block, Room 402',
        officeHours: 'Tue & Thu, 3:00–5:00 PM',
      },
      {
        name: 'Dr. Sneha Kulkarni',
        department: 'Humanities',
        designation: 'Assistant Professor',
        email: 'sneha.kulkarni@college.edu',
        officeRoom: 'Arts Block, Room 15',
        officeHours: 'Mon & Thu, 9:00–11:00 AM',
        bio: 'Teaches communication skills and technical writing.',
      },
      {
        name: 'Dr. Arjun Desai',
        department: 'Physics',
        designation: 'Associate Professor',
        email: 'arjun.desai@college.edu',
        officeRoom: 'Science Block, Room 210',
        officeHours: 'Tue & Fri, 2:00–4:00 PM',
      },
    ],
  });

  // ---------- Timetable (for demo student) ----------
  const timetableSeed: { day: DayOfWeek; startTime: string; endTime: string; courseCode: string; courseName: string; room: string; instructor: string; color: string }[] = [
    { day: 'MONDAY', startTime: '09:00', endTime: '10:00', courseCode: 'CS101', courseName: 'Intro to Programming', room: 'CS Lab 1', instructor: 'Dr. Karthik Iyer', color: '#2563eb' },
    { day: 'MONDAY', startTime: '10:15', endTime: '11:15', courseCode: 'MA101', courseName: 'Calculus I', room: 'Room 110', instructor: 'Dr. Fatima Sheikh', color: '#0d9488' },
    { day: 'TUESDAY', startTime: '09:00', endTime: '10:00', courseCode: 'PH101', courseName: 'Physics I', room: 'Room 210', instructor: 'Dr. Arjun Desai', color: '#16a34a' },
    { day: 'TUESDAY', startTime: '11:00', endTime: '13:00', courseCode: 'CS102', courseName: 'Programming Lab', room: 'CS Lab 2', instructor: 'Dr. Karthik Iyer', color: '#2563eb' },
    { day: 'WEDNESDAY', startTime: '09:00', endTime: '10:00', courseCode: 'CS101', courseName: 'Intro to Programming', room: 'CS Lab 1', instructor: 'Dr. Karthik Iyer', color: '#2563eb' },
    { day: 'WEDNESDAY', startTime: '14:00', endTime: '15:00', courseCode: 'HU101', courseName: 'Communication Skills', room: 'Arts Block 15', instructor: 'Dr. Sneha Kulkarni', color: '#7c3aed' },
    { day: 'THURSDAY', startTime: '09:00', endTime: '10:00', courseCode: 'MA101', courseName: 'Calculus I', room: 'Room 110', instructor: 'Dr. Fatima Sheikh', color: '#0d9488' },
    { day: 'THURSDAY', startTime: '10:15', endTime: '11:15', courseCode: 'PH101', courseName: 'Physics I', room: 'Room 210', instructor: 'Dr. Arjun Desai', color: '#16a34a' },
    { day: 'FRIDAY', startTime: '09:00', endTime: '11:00', courseCode: 'PH102', courseName: 'Physics Lab', room: 'Physics Lab 1', instructor: 'Dr. Arjun Desai', color: '#16a34a' },
    { day: 'FRIDAY', startTime: '15:00', endTime: '17:00', courseCode: 'CS103', courseName: 'Coding Club Session', room: 'CS Lab 3', instructor: 'Coding Club', color: '#f59e0b' },
  ];

  await prisma.timetableEntry.createMany({
    data: timetableSeed.map((t) => ({ ...t, userId: student.id })),
  });

  console.log('Seeding complete!');
  console.log('Demo login: alex.student@college.edu / password123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
