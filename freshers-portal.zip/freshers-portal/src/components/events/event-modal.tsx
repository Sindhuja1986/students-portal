'use client';

import { useState } from 'react';
import Image from 'next/image';
import { useSession } from 'next-auth/react';
import { CalendarDays, MapPin, Users, Loader2, CheckCircle2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatDate, formatTime } from '@/lib/utils';
import { toast } from 'sonner';
import type { EventWithMeta } from './event-card';

export function EventModal({
  event,
  open,
  onOpenChange,
  onRegistered,
}: {
  event: EventWithMeta | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onRegistered?: () => void;
}) {
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);
  const [registered, setRegistered] = useState(false);

  if (!event) return null;

  async function handleRegister() {
    if (!session) {
      toast.error('Please sign in to register for events.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`/api/events/${event!.id}/register`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? 'Registration failed.');
      } else {
        setRegistered(true);
        toast.success(
          data.status === 'WAITLISTED' ? "You're on the waitlist!" : "You're registered! 🎉"
        );
        onRegistered?.();
      }
    } catch {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="p-0 overflow-hidden">
        <div className="relative h-48 w-full bg-hero-gradient">
          {event.posterUrl ? (
            <Image src={event.posterUrl} alt={event.title} fill className="object-cover" />
          ) : (
            <div className="flex h-full items-center justify-center text-6xl">🎓</div>
          )}
        </div>
        <div className="p-6">
          <DialogHeader>
            <Badge className="mb-2 w-fit">{event.category.replace('_', ' ')}</Badge>
            <DialogTitle className="text-xl">{event.title}</DialogTitle>
            <DialogDescription className="whitespace-pre-line pt-1">{event.description}</DialogDescription>
          </DialogHeader>

          <div className="mt-4 space-y-2 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <CalendarDays className="h-4 w-4" />
              {formatDate(event.startTime)} · {formatTime(event.startTime)} – {formatTime(event.endTime)}
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              {event.venue}
            </div>
            {event._count && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Users className="h-4 w-4" />
                {event._count.registrations} registered{event.capacity ? ` / ${event.capacity} spots` : ''}
              </div>
            )}
            {event.club && <p className="text-muted-foreground">Hosted by <strong>{event.club.name}</strong></p>}
          </div>

          <DialogFooter className="mt-6">
            <Button onClick={handleRegister} disabled={loading || registered} className="w-full sm:w-auto">
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {registered ? (
                <>
                  <CheckCircle2 className="mr-2 h-4 w-4" /> Registered
                </>
              ) : (
                'Register for this event'
              )}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}
