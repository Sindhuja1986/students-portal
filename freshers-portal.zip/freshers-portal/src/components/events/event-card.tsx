'use client';

import Image from 'next/image';
import { CalendarDays, MapPin, Users } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDate, formatTime } from '@/lib/utils';

export type EventWithMeta = {
  id: string;
  title: string;
  description: string;
  category: string;
  venue: string;
  startTime: string;
  endTime: string;
  posterUrl?: string | null;
  isFeatured: boolean;
  capacity?: number | null;
  club?: { id: string; name: string } | null;
  _count?: { registrations: number };
};

const CATEGORY_COLORS: Record<string, 'default' | 'info' | 'success' | 'warning' | 'secondary'> = {
  WELCOME: 'warning',
  ACADEMIC: 'info',
  CULTURAL: 'secondary',
  SPORTS: 'success',
  TECHNICAL: 'info',
  WORKSHOP: 'secondary',
  EXAM: 'warning',
  HOLIDAY: 'success',
  CLUB_MEETING: 'default',
  OTHER: 'default',
};

export function EventCard({ event, onClick }: { event: EventWithMeta; onClick: () => void }) {
  return (
    <Card
      onClick={onClick}
      className="cursor-pointer overflow-hidden transition-all hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="relative h-36 w-full bg-hero-gradient">
        {event.posterUrl ? (
          <Image src={event.posterUrl} alt={event.title} fill className="object-cover" />
        ) : (
          <div className="flex h-full items-center justify-center text-4xl">🎓</div>
        )}
        {event.isFeatured && (
          <Badge variant="warning" className="absolute left-2 top-2">
            ⭐ Featured
          </Badge>
        )}
      </div>
      <CardContent className="p-4">
        <Badge variant={CATEGORY_COLORS[event.category] ?? 'default'} className="mb-2">
          {event.category.replace('_', ' ')}
        </Badge>
        <h3 className="line-clamp-1 font-semibold">{event.title}</h3>
        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{event.description}</p>
        <div className="mt-3 space-y-1 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <CalendarDays className="h-3.5 w-3.5" />
            {formatDate(event.startTime)} · {formatTime(event.startTime)} - {formatTime(event.endTime)}
          </div>
          <div className="flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5" />
            {event.venue}
          </div>
          {event._count && (
            <div className="flex items-center gap-1.5">
              <Users className="h-3.5 w-3.5" />
              {event._count.registrations} registered{event.capacity ? ` / ${event.capacity}` : ''}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
