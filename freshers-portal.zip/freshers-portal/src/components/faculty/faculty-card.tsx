import Image from 'next/image';
import { Mail, Clock, Building2, Phone } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { initials } from '@/lib/utils';

export type FacultyItem = {
  id: string;
  name: string;
  department: string;
  designation?: string | null;
  email: string;
  phone?: string | null;
  officeRoom?: string | null;
  officeHours?: string | null;
  photoUrl?: string | null;
};

export function FacultyCard({ faculty }: { faculty: FacultyItem }) {
  return (
    <Card className="transition-shadow hover:shadow-md">
      <CardContent className="flex gap-4 p-5">
        <Avatar className="h-16 w-16 flex-shrink-0">
          <AvatarImage src={faculty.photoUrl ?? undefined} alt={faculty.name} />
          <AvatarFallback className="text-lg">{initials(faculty.name)}</AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <h3 className="font-semibold">{faculty.name}</h3>
          <Badge variant="secondary" className="mt-1">{faculty.department}</Badge>
          {faculty.designation && <p className="mt-1 text-xs text-muted-foreground">{faculty.designation}</p>}

          <div className="mt-2 space-y-1 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5 truncate">
              <Mail className="h-3.5 w-3.5 flex-shrink-0" /> {faculty.email}
            </div>
            {faculty.phone && (
              <div className="flex items-center gap-1.5">
                <Phone className="h-3.5 w-3.5 flex-shrink-0" /> {faculty.phone}
              </div>
            )}
            {faculty.officeRoom && (
              <div className="flex items-center gap-1.5">
                <Building2 className="h-3.5 w-3.5 flex-shrink-0" /> {faculty.officeRoom}
              </div>
            )}
            {faculty.officeHours && (
              <div className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5 flex-shrink-0" /> {faculty.officeHours}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
