'use client';

import { useMemo } from 'react';
import { cn } from '@/lib/utils';

type CalEvent = {
  id: string;
  title: string;
  category: string;
  startTime: string;
};

const CATEGORY_COLOR: Record<string, string> = {
  WELCOME: 'bg-brand-amber',
  ACADEMIC: 'bg-brand-blue',
  CULTURAL: 'bg-brand-purple',
  SPORTS: 'bg-brand-green',
  TECHNICAL: 'bg-brand-blue',
  WORKSHOP: 'bg-brand-purple',
  EXAM: 'bg-red-500',
  HOLIDAY: 'bg-brand-green',
  CLUB_MEETING: 'bg-brand-teal',
  OTHER: 'bg-slate-400',
};

export function CalendarView({ events, month, year }: { events: CalEvent[]; month: number; year: number }) {
  const { days, firstDayOffset } = useMemo(() => {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDayOffset = new Date(year, month, 1).getDay();
    return { days: Array.from({ length: daysInMonth }, (_, i) => i + 1), firstDayOffset };
  }, [month, year]);

  const eventsByDay = useMemo(() => {
    const map: Record<number, CalEvent[]> = {};
    events.forEach((e) => {
      const d = new Date(e.startTime);
      if (d.getMonth() === month && d.getFullYear() === year) {
        map[d.getDate()] = [...(map[d.getDate()] ?? []), e];
      }
    });
    return map;
  }, [events, month, year]);

  const today = new Date();
  const isCurrentMonth = today.getMonth() === month && today.getFullYear() === year;

  return (
    <div className="overflow-hidden rounded-xl border">
      <div className="grid grid-cols-7 border-b bg-muted/50 text-center text-xs font-semibold">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
          <div key={d} className="py-2">
            {d}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {Array.from({ length: firstDayOffset }).map((_, i) => (
          <div key={`empty-${i}`} className="min-h-[90px] border-b border-r bg-muted/20" />
        ))}
        {days.map((day) => (
          <div
            key={day}
            className={cn(
              'min-h-[90px] border-b border-r p-1.5',
              isCurrentMonth && day === today.getDate() && 'bg-primary/5'
            )}
          >
            <span
              className={cn(
                'inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-medium',
                isCurrentMonth && day === today.getDate() && 'bg-primary text-primary-foreground'
              )}
            >
              {day}
            </span>
            <div className="mt-1 space-y-0.5">
              {(eventsByDay[day] ?? []).slice(0, 3).map((e) => (
                <div
                  key={e.id}
                  title={e.title}
                  className={cn('truncate rounded px-1 py-0.5 text-[10px] text-white', CATEGORY_COLOR[e.category] ?? 'bg-slate-400')}
                >
                  {e.title}
                </div>
              ))}
              {(eventsByDay[day] ?? []).length > 3 && (
                <p className="text-[10px] text-muted-foreground">+{eventsByDay[day].length - 3} more</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
