'use client';

import { Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

export type TimetableEntryItem = {
  id: string;
  day: string;
  startTime: string;
  endTime: string;
  courseCode: string;
  courseName: string;
  room?: string | null;
  instructor?: string | null;
  color: string;
};

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const DAY_LABELS: Record<string, string> = {
  MONDAY: 'Mon',
  TUESDAY: 'Tue',
  WEDNESDAY: 'Wed',
  THURSDAY: 'Thu',
  FRIDAY: 'Fri',
  SATURDAY: 'Sat',
};

export function TimetableGrid({
  entries,
  onDelete,
}: {
  entries: TimetableEntryItem[];
  onDelete: (id: string) => void;
}) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      {DAYS.map((day) => {
        const dayEntries = entries
          .filter((e) => e.day === day)
          .sort((a, b) => a.startTime.localeCompare(b.startTime));

        return (
          <div key={day} className="rounded-xl border bg-card">
            <div className="border-b bg-muted/50 px-3 py-2 text-center text-sm font-semibold">
              {DAY_LABELS[day]}
            </div>
            <div className="space-y-2 p-2 min-h-[120px]">
              {dayEntries.length === 0 ? (
                <p className="py-4 text-center text-xs text-muted-foreground">No classes</p>
              ) : (
                dayEntries.map((entry) => (
                  <div
                    key={entry.id}
                    className="group relative rounded-lg p-2.5 text-xs text-white shadow-sm"
                    style={{ backgroundColor: entry.color }}
                  >
                    <p className="font-semibold">{entry.courseCode}</p>
                    <p className="line-clamp-1 opacity-90">{entry.courseName}</p>
                    <p className="mt-1 opacity-80">
                      {entry.startTime}–{entry.endTime}
                    </p>
                    {entry.room && <p className="opacity-80">📍 {entry.room}</p>}
                    <button
                      onClick={() => onDelete(entry.id)}
                      className="absolute right-1 top-1 rounded p-0.5 opacity-0 transition-opacity hover:bg-black/20 group-hover:opacity-100"
                      aria-label="Delete class"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
