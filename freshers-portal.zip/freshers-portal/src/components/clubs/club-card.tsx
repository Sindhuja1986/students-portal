import { Users, Clock, MapPin, Mail } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '@/lib/utils';

export type ClubWithEvents = {
  id: string;
  name: string;
  category: string;
  description: string;
  logoUrl?: string | null;
  meetingTime?: string | null;
  meetingVenue?: string | null;
  contactEmail?: string | null;
  memberCount: number;
  events: { id: string; title: string; startTime: string }[];
};

const CLUB_EMOJI: Record<string, string> = {
  Technical: '💻',
  Cultural: '🎭',
  Sports: '⚽',
  Arts: '🎨',
  Literary: '📚',
  Music: '🎵',
  Social: '🤝',
};

export function ClubCard({ club }: { club: ClubWithEvents }) {
  return (
    <Card className="h-full transition-shadow hover:shadow-md">
      <CardContent className="p-5">
        <div className="flex items-start gap-3">
          <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-hero-gradient text-2xl">
            {CLUB_EMOJI[club.category] ?? '🏛️'}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold">{club.name}</h3>
            </div>
            <Badge variant="secondary" className="mt-1">{club.category}</Badge>
          </div>
        </div>

        <p className="mt-3 line-clamp-2 text-sm text-muted-foreground">{club.description}</p>

        <div className="mt-3 space-y-1.5 text-xs text-muted-foreground">
          {club.meetingTime && (
            <div className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" /> {club.meetingTime}
            </div>
          )}
          {club.meetingVenue && (
            <div className="flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5" /> {club.meetingVenue}
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <Users className="h-3.5 w-3.5" /> {club.memberCount} members
          </div>
          {club.contactEmail && (
            <div className="flex items-center gap-1.5">
              <Mail className="h-3.5 w-3.5" /> {club.contactEmail}
            </div>
          )}
        </div>

        {club.events.length > 0 && (
          <div className="mt-4 border-t pt-3">
            <p className="mb-1.5 text-xs font-semibold uppercase text-muted-foreground">Upcoming</p>
            <ul className="space-y-1">
              {club.events.map((e) => (
                <li key={e.id} className="text-xs">
                  <span className="font-medium">{e.title}</span> — {formatDate(e.startTime)}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
