import Link from 'next/link';
import { PartyPopper, ArrowRight, CalendarDays, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function WelcomeBanner({ studentName }: { studentName: string }) {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-hero-gradient p-8 text-white shadow-lg sm:p-10">
      {/* Decorative shapes */}
      <div className="pointer-events-none absolute -right-10 -top-10 h-48 w-48 rounded-full bg-white/10" />
      <div className="pointer-events-none absolute -bottom-16 left-1/3 h-56 w-56 rounded-full bg-white/10" />

      <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="max-w-xl">
          <p className="text-sm font-medium uppercase tracking-wide text-white/80">Welcome back,</p>
          <h1 className="mt-1 text-3xl font-bold sm:text-4xl">{studentName} 👋</h1>
          <p className="mt-3 text-white/90">
            Everything you need for a great start at college — events, clubs, timetable, and more —
            lives right here.
          </p>
        </div>

        <div className="flex-shrink-0 rounded-xl bg-white/15 p-5 backdrop-blur-sm ring-1 ring-white/25 sm:w-80">
          <div className="mb-3 flex items-center gap-2">
            <PartyPopper className="h-5 w-5" />
            <span className="text-xs font-bold uppercase tracking-wider">Featured Event</span>
          </div>
          <h2 className="text-xl font-bold leading-tight">🎉 Freshers Welcome Party</h2>
          <div className="mt-3 space-y-1.5 text-sm text-white/90">
            <div className="flex items-center gap-2">
              <CalendarDays className="h-4 w-4" />
              <span>Sat, Aug 2 · 6:00 PM</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              <span>Main Auditorium Lawn</span>
            </div>
          </div>
          <Button asChild variant="secondary" size="sm" className="mt-4 w-full bg-white text-primary hover:bg-white/90">
            <Link href="/events">
              Join the Party <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
