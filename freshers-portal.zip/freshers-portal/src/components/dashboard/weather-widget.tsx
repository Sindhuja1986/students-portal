'use client';

import { useEffect, useState } from 'react';
import { Sun, Cloud, CloudRain, CloudSnow, CloudFog, CloudLightning, CloudDrizzle, Wind, Droplets } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

type Weather = {
  location: string;
  tempC: number;
  humidity: number | null;
  windKph: number;
  condition: string;
  icon: string;
  highC: number;
  lowC: number;
};

const ICONS: Record<string, React.ElementType> = {
  sun: Sun,
  cloud: Cloud,
  'cloud-sun': Cloud,
  'cloud-rain': CloudRain,
  'cloud-rain-wind': CloudRain,
  'cloud-snow': CloudSnow,
  'cloud-fog': CloudFog,
  'cloud-lightning': CloudLightning,
  'cloud-drizzle': CloudDrizzle,
};

export function WeatherWidget() {
  const [weather, setWeather] = useState<Weather | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetch('/api/weather')
      .then((res) => res.json())
      .then(setWeather)
      .catch(() => setError(true));
  }, []);

  const Icon = weather ? ICONS[weather.icon] ?? Cloud : Cloud;

  return (
    <Card className="h-full">
      <CardContent className="flex h-full flex-col justify-between p-5">
        {error ? (
          <p className="text-sm text-muted-foreground">Weather unavailable right now.</p>
        ) : !weather ? (
          <div className="animate-pulse space-y-3">
            <div className="h-4 w-24 rounded bg-muted" />
            <div className="h-10 w-16 rounded bg-muted" />
          </div>
        ) : (
          <>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{weather.location}</p>
                <p className="text-3xl font-bold">{weather.tempC}°C</p>
                <p className="text-sm text-muted-foreground">{weather.condition}</p>
              </div>
              <Icon className="h-10 w-10 text-brand-amber" />
            </div>
            <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
              <span>H: {weather.highC}° L: {weather.lowC}°</span>
              <span className="flex items-center gap-1">
                <Wind className="h-3.5 w-3.5" /> {weather.windKph} km/h
              </span>
              {weather.humidity !== null && (
                <span className="flex items-center gap-1">
                  <Droplets className="h-3.5 w-3.5" /> {weather.humidity}%
                </span>
              )}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
