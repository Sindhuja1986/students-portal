'use client';

import { useRef } from 'react';
import Link from 'next/link';
import { ChevronLeft, ChevronRight, CalendarDays, MapPin } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatDate, formatTime } from '@/lib/utils';

type EventItem = {
  id: string;
  title: string;
  venue: string;
  startTime: string;
  category: string;
};

export function EventsCarousel({ events }: { events: EventItem[] }) {
  const scrollRef = useRef<HTMLDivElement>(null);

  function scroll(dir: 'left' | 'right') {
    scrollRef.current?.scrollBy({ left: dir === 'left' ? -300 : 300, behavior: 'smooth' });
  }

  if (events.length === 0) {
    return <p className="text-sm text-muted-foreground">No upcoming events right now — check back soon!</p>;
  }

  return (
    <div className="relative">
      <div ref={scrollRef} className="scrollbar-thin flex gap-4 overflow-x-auto pb-2 scroll-smooth">
        {events.map((event) => (
          <Link
            key={event.id}
            href="/events"
            className="min-w-[240px] max-w-[240px] flex-shrink-0 rounded-xl border bg-card p-4 shadow-sm transition-shadow hover:shadow-md"
          >
            <Badge variant="info" className="mb-2">{event.category}</Badge>
            <h3 className="line-clamp-2 font-semibold">{event.title}</h3>
            <div className="mt-3 space-y-1 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <CalendarDays className="h-3.5 w-3.5" />
                {formatDate(event.startTime)} · {formatTime(event.startTime)}
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5" />
                {event.venue}
              </div>
            </div>
          </Link>
        ))}
      </div>

      <div className="mt-2 flex justify-end gap-2">
        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => scroll('left')}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => scroll('right')}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
