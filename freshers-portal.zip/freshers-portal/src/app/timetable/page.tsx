'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import { Plus, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { TimetableGrid, type TimetableEntryItem } from '@/components/timetable/timetable-grid';
import { toast } from 'sonner';

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const COLORS = ['#2563eb', '#0d9488', '#16a34a', '#f59e0b', '#7c3aed', '#dc2626'];

const emptyForm = {
  day: 'MONDAY',
  startTime: '09:00',
  endTime: '10:00',
  courseCode: '',
  courseName: '',
  room: '',
  instructor: '',
  color: COLORS[0],
};

export default function TimetablePage() {
  const { data: session, status } = useSession();
  const [entries, setEntries] = useState<TimetableEntryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  async function loadEntries() {
    setLoading(true);
    const res = await fetch('/api/timetable');
    if (res.ok) setEntries(await res.json());
    setLoading(false);
  }

  useEffect(() => {
    if (status === 'authenticated') loadEntries();
    else if (status === 'unauthenticated') setLoading(false);
  }, [status]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.courseCode || !form.courseName) {
      toast.error('Course code and name are required.');
      return;
    }
    setSaving(true);
    const res = await fetch('/api/timetable', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    setSaving(false);
    if (res.ok) {
      toast.success('Class added!');
      setForm(emptyForm);
      setOpen(false);
      loadEntries();
    } else {
      toast.error('Could not add class.');
    }
  }

  async function handleDelete(id: string) {
    setEntries((prev) => prev.filter((e) => e.id !== id));
    await fetch(`/api/timetable/${id}`, { method: 'DELETE' });
  }

  if (status === 'unauthenticated') {
    return (
      <div className="container flex min-h-[50vh] flex-col items-center justify-center gap-3 py-8 text-center">
        <h1 className="text-2xl font-bold">My Timetable</h1>
        <p className="text-muted-foreground">Sign in to build and save your personal class schedule.</p>
        <Button asChild>
          <Link href="/login">Sign in</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container space-y-6 py-8">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold sm:text-3xl">My Timetable</h1>
          <p className="mt-1 text-muted-foreground">Your personalized weekly class schedule.</p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus className="mr-1.5 h-4 w-4" /> Add Class
        </Button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-40 animate-pulse rounded-xl bg-muted" />
          ))}
        </div>
      ) : (
        <TimetableGrid entries={entries} onDelete={handleDelete} />
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add a Class</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Day</Label>
                <Select value={form.day} onValueChange={(v) => setForm({ ...form, day: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DAYS.map((d) => (
                      <SelectItem key={d} value={d}>
                        {d.charAt(0) + d.slice(1).toLowerCase()}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Color</Label>
                <div className="flex gap-1.5 pt-2">
                  {COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      className="h-6 w-6 rounded-full ring-offset-2 transition-all"
                      style={{ backgroundColor: c, outline: form.color === c ? `2px solid ${c}` : 'none' }}
                      onClick={() => setForm({ ...form, color: c })}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Start Time</Label>
                <Input type="time" value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>End Time</Label>
                <Input type="time" value={form.endTime} onChange={(e) => setForm({ ...form, endTime: e.target.value })} />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Course Code</Label>
              <Input placeholder="CS101" value={form.courseCode} onChange={(e) => setForm({ ...form, courseCode: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Course Name</Label>
              <Input placeholder="Intro to Programming" value={form.courseName} onChange={(e) => setForm({ ...form, courseName: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Room</Label>
                <Input placeholder="B204" value={form.room} onChange={(e) => setForm({ ...form, room: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Instructor</Label>
                <Input placeholder="Dr. Smith" value={form.instructor} onChange={(e) => setForm({ ...form, instructor: e.target.value })} />
              </div>
            </div>

            <DialogFooter>
              <Button type="submit" disabled={saving} className="w-full sm:w-auto">
                {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Save Class
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
