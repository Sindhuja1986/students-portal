import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from '@/components/providers';
import { Navbar } from '@/components/layout/navbar';
import { ChatWidget } from '@/components/chatbot/chat-widget';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });

export const metadata: Metadata = {
  title: {
    default: 'Freshers Portal | Your Campus Companion',
    template: '%s | Freshers Portal',
  },
  description:
    'The centralized hub for new college students — events, clubs, faculty directory, timetable, calendar, registration, and an AI assistant, all in one place.',
  keywords: ['freshers portal', 'college', 'campus', 'student portal', 'orientation'],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <Providers>
          <div className="relative flex min-h-screen flex-col">
            <Navbar />
            <main className="flex-1">{children}</main>
            <ChatWidget />
          </div>
        </Providers>
      </body>
    </html>
  );
}
