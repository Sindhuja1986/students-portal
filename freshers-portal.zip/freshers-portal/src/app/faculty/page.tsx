'use client';

import { useEffect, useState } from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { FacultyCard, type FacultyItem } from '@/components/faculty/faculty-card';

export default function FacultyPage() {
  const [faculty, setFaculty] = useState<FacultyItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const t = setTimeout(async () => {
      setLoading(true);
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      const res = await fetch(`/api/faculty?${params.toString()}`);
      const data = await res.json();
      setFaculty(Array.isArray(data) ? data : []);
      setLoading(false);
    }, 200);
    return () => clearTimeout(t);
  }, [search]);

  return (
    <div className="container space-y-8 py-8">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">Faculty Directory</h1>
        <p className="mt-1 text-muted-foreground">Find contact details and office hours for every department.</p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search by name, department, or email..."
          className="pl-9"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-32 animate-pulse rounded-xl bg-muted" />
          ))}
        </div>
      ) : faculty.length === 0 ? (
        <p className="py-12 text-center text-muted-foreground">No faculty found.</p>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {faculty.map((f) => (
            <FacultyCard key={f.id} faculty={f} />
          ))}
        </div>
      )}
    </div>
  );
}
