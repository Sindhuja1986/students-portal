'use client';

import { useEffect, useMemo, useState } from 'react';
import { Search, PartyPopper } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { EventCard, type EventWithMeta } from '@/components/events/event-card';
import { EventModal } from '@/components/events/event-modal';
import { formatDate, formatTime } from '@/lib/utils';

const CATEGORIES = [
  'ALL',
  'WELCOME',
  'ACADEMIC',
  'CULTURAL',
  'SPORTS',
  'TECHNICAL',
  'WORKSHOP',
  'EXAM',
  'HOLIDAY',
  'CLUB_MEETING',
  'OTHER',
];

export default function EventsPage() {
  const [events, setEvents] = useState<EventWithMeta[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('ALL');
  const [selected, setSelected] = useState<EventWithMeta | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  async function loadEvents() {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (category !== 'ALL') params.set('category', category);
    const res = await fetch(`/api/events?${params.toString()}`);
    const data = await res.json();
    setEvents(Array.isArray(data) ? data : []);
    setLoading(false);
  }

  useEffect(() => {
    const t = setTimeout(loadEvents, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, category]);

  const featured = useMemo(() => events.find((e) => e.isFeatured), [events]);

  return (
    <div className="container space-y-8 py-8">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">Campus Events</h1>
        <p className="mt-1 text-muted-foreground">Browse, search, and register for everything happening on campus.</p>
      </div>

      {featured && (
        <div className="relative overflow-hidden rounded-2xl bg-hero-gradient p-6 text-white shadow-lg sm:p-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2 text-sm font-bold uppercase tracking-wide">
                <PartyPopper className="h-4 w-4" /> Don't Miss
              </div>
              <h2 className="text-2xl font-bold">{featured.title}</h2>
              <p className="mt-1 text-white/90">
                {formatDate(featured.startTime)} · {formatTime(featured.startTime)} · {featured.venue}
              </p>
            </div>
            <Button
              variant="secondary"
              className="bg-white text-primary hover:bg-white/90"
              onClick={() => {
                setSelected(featured);
                setModalOpen(true);
              }}
            >
              View Details
            </Button>
          </div>
        </div>
      )}

      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search events..."
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="sm:w-56">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            {CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>
                {c === 'ALL' ? 'All Categories' : c.replace('_', ' ')}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-72 animate-pulse rounded-xl bg-muted" />
          ))}
        </div>
      ) : events.length === 0 ? (
        <p className="py-12 text-center text-muted-foreground">No events found. Try a different search or filter.</p>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {events.map((event) => (
            <EventCard
              key={event.id}
              event={event}
              onClick={() => {
                setSelected(event);
                setModalOpen(true);
              }}
            />
          ))}
        </div>
      )}

      <EventModal event={selected} open={modalOpen} onOpenChange={setModalOpen} onRegistered={loadEvents} />
    </div>
  );
}
