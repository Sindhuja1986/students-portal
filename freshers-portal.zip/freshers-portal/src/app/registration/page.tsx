'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import { Loader2, BookOpen, Building, LibraryBig, CheckCircle2 } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { toast } from 'sonner';

function useSubmission() {
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  async function submit(type: 'COURSE' | 'HOSTEL' | 'LIBRARY', data: Record<string, string>) {
    // basic validation: no empty required fields
    if (Object.values(data).some((v) => !v || !v.trim())) {
      toast.error('Please fill in all required fields.');
      return;
    }
    setSubmitting(true);
    const res = await fetch('/api/registrations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type, data }),
    });
    setSubmitting(false);
    if (res.ok) {
      setDone(true);
      toast.success('Submitted successfully!');
    } else {
      toast.error('Submission failed. Please try again.');
    }
  }

  return { submitting, done, submit, reset: () => setDone(false) };
}

function CourseForm() {
  const { submitting, done, submit, reset } = useSubmission();
  const [form, setForm] = useState({ department: '', courseCode: '', semester: '', section: '' });

  if (done) return <SuccessState onReset={reset} label="course registration" />;

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        submit('COURSE', form);
      }}
      className="space-y-4"
    >
      <div className="space-y-1.5">
        <Label>Department</Label>
        <Input placeholder="Computer Science" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>Course Code</Label>
          <Input placeholder="CS101" value={form.courseCode} onChange={(e) => setForm({ ...form, courseCode: e.target.value })} />
        </div>
        <div className="space-y-1.5">
          <Label>Semester</Label>
          <Input placeholder="1" value={form.semester} onChange={(e) => setForm({ ...form, semester: e.target.value })} />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Preferred Section</Label>
        <Input placeholder="A" value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })} />
      </div>
      <Button type="submit" disabled={submitting} className="w-full">
        {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        Submit Course Registration
      </Button>
    </form>
  );
}

function HostelForm() {
  const { submitting, done, submit, reset } = useSubmission();
  const [form, setForm] = useState({ roomType: '', block: '', emergencyContact: '', dietaryPreference: '' });

  if (done) return <SuccessState onReset={reset} label="hostel registration" />;

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        submit('HOSTEL', form);
      }}
      className="space-y-4"
    >
      <div className="space-y-1.5">
        <Label>Room Type</Label>
        <Select value={form.roomType} onValueChange={(v) => setForm({ ...form, roomType: v })}>
          <SelectTrigger>
            <SelectValue placeholder="Select room type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Single">Single</SelectItem>
            <SelectItem value="Double">Double</SelectItem>
            <SelectItem value="Triple">Triple</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1.5">
        <Label>Preferred Block</Label>
        <Input placeholder="Block C" value={form.block} onChange={(e) => setForm({ ...form, block: e.target.value })} />
      </div>
      <div className="space-y-1.5">
        <Label>Emergency Contact Number</Label>
        <Input placeholder="+91 98765 43210" value={form.emergencyContact} onChange={(e) => setForm({ ...form, emergencyContact: e.target.value })} />
      </div>
      <div className="space-y-1.5">
        <Label>Dietary Preference</Label>
        <Input placeholder="Vegetarian" value={form.dietaryPreference} onChange={(e) => setForm({ ...form, dietaryPreference: e.target.value })} />
      </div>
      <Button type="submit" disabled={submitting} className="w-full">
        {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        Submit Hostel Registration
      </Button>
    </form>
  );
}

function LibraryForm() {
  const { submitting, done, submit, reset } = useSubmission();
  const [form, setForm] = useState({ studentId: '', cardType: '' });

  if (done) return <SuccessState onReset={reset} label="library registration" />;

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        submit('LIBRARY', form);
      }}
      className="space-y-4"
    >
      <div className="space-y-1.5">
        <Label>Student ID / Roll Number</Label>
        <Input placeholder="21CS1042" value={form.studentId} onChange={(e) => setForm({ ...form, studentId: e.target.value })} />
      </div>
      <div className="space-y-1.5">
        <Label>Card Type</Label>
        <Select value={form.cardType} onValueChange={(v) => setForm({ ...form, cardType: v })}>
          <SelectTrigger>
            <SelectValue placeholder="Select card type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Standard">Standard (5 books)</SelectItem>
            <SelectItem value="Extended">Extended (10 books)</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button type="submit" disabled={submitting} className="w-full">
        {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        Submit Library Registration
      </Button>
    </form>
  );
}

function SuccessState({ onReset, label }: { onReset: () => void; label: string }) {
  return (
    <div className="flex flex-col items-center gap-3 py-8 text-center">
      <CheckCircle2 className="h-12 w-12 text-brand-green" />
      <p className="font-semibold">Your {label} was submitted!</p>
      <p className="text-sm text-muted-foreground">You'll get a confirmation once it's reviewed by staff.</p>
      <Button variant="outline" size="sm" onClick={onReset}>
        Submit another
      </Button>
    </div>
  );
}

export default function RegistrationPage() {
  const { status } = useSession();

  if (status === 'unauthenticated') {
    return (
      <div className="container flex min-h-[50vh] flex-col items-center justify-center gap-3 py-8 text-center">
        <h1 className="text-2xl font-bold">Registration Hub</h1>
        <p className="text-muted-foreground">Sign in to submit course, hostel, or library registrations.</p>
        <Button asChild>
          <Link href="/login">Sign in</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container max-w-2xl space-y-6 py-8">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">Registration Hub</h1>
        <p className="mt-1 text-muted-foreground">Guided forms for the essentials — no more standing in line.</p>
      </div>

      <Card>
        <CardContent className="p-6">
          <Tabs defaultValue="course">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="course">
                <BookOpen className="mr-1.5 h-4 w-4" /> Course
              </TabsTrigger>
              <TabsTrigger value="hostel">
                <Building className="mr-1.5 h-4 w-4" /> Hostel
              </TabsTrigger>
              <TabsTrigger value="library">
                <LibraryBig className="mr-1.5 h-4 w-4" /> Library
              </TabsTrigger>
            </TabsList>
            <TabsContent value="course">
              <CourseForm />
            </TabsContent>
            <TabsContent value="hostel">
              <HostelForm />
            </TabsContent>
            <TabsContent value="library">
              <LibraryForm />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
