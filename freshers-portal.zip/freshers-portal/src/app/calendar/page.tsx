'use client';

import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CalendarView } from '@/components/calendar/calendar-view';

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const LEGEND = [
  { label: 'Welcome', color: 'bg-brand-amber' },
  { label: 'Academic', color: 'bg-brand-blue' },
  { label: 'Cultural', color: 'bg-brand-purple' },
  { label: 'Sports', color: 'bg-brand-green' },
  { label: 'Exam', color: 'bg-red-500' },
  { label: 'Club Meeting', color: 'bg-brand-teal' },
];

export default function CalendarPage() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth());
  const [year, setYear] = useState(now.getFullYear());
  const [events, setEvents] = useState<{ id: string; title: string; category: string; startTime: string }[]>([]);

  useEffect(() => {
    const from = new Date(year, month, 1).toISOString();
    const to = new Date(year, month + 1, 0, 23, 59, 59).toISOString();
    fetch(`/api/events?from=${from}&to=${to}`)
      .then((res) => res.json())
      .then((data) => setEvents(Array.isArray(data) ? data : []))
      .catch(() => setEvents([]));
  }, [month, year]);

  function changeMonth(delta: number) {
    let m = month + delta;
    let y = year;
    if (m < 0) { m = 11; y -= 1; }
    if (m > 11) { m = 0; y += 1; }
    setMonth(m);
    setYear(y);
  }

  return (
    <div className="container space-y-6 py-8">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">Calendar</h1>
        <p className="mt-1 text-muted-foreground">Events, exams, holidays, and club meetings — all in one view.</p>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">
          {MONTH_NAMES[month]} {year}
        </h2>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={() => changeMonth(-1)}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => { setMonth(now.getMonth()); setYear(now.getFullYear()); }}>
            Today
          </Button>
          <Button variant="outline" size="icon" onClick={() => changeMonth(1)}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        {LEGEND.map((l) => (
          <div key={l.label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className={`h-2.5 w-2.5 rounded-full ${l.color}`} />
            {l.label}
          </div>
        ))}
      </div>

      <CalendarView events={events} month={month} year={year} />
    </div>
  );
}
