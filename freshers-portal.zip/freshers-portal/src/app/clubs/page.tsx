'use client';

import { useEffect, useState } from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { ClubCard, type ClubWithEvents } from '@/components/clubs/club-card';

const CATEGORIES = ['ALL', 'Technical', 'Cultural', 'Sports', 'Arts', 'Literary', 'Music', 'Social'];

export default function ClubsPage() {
  const [clubs, setClubs] = useState<ClubWithEvents[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('ALL');

  useEffect(() => {
    const t = setTimeout(async () => {
      setLoading(true);
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (category !== 'ALL') params.set('category', category);
      const res = await fetch(`/api/clubs?${params.toString()}`);
      const data = await res.json();
      setClubs(Array.isArray(data) ? data : []);
      setLoading(false);
    }, 300);
    return () => clearTimeout(t);
  }, [search, category]);

  return (
    <div className="container space-y-8 py-8">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">Clubs & Societies</h1>
        <p className="mt-1 text-muted-foreground">Find your people — from coding to drama to sports.</p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search clubs..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="sm:w-56">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            {CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>
                {c === 'ALL' ? 'All Categories' : c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-56 animate-pulse rounded-xl bg-muted" />
          ))}
        </div>
      ) : clubs.length === 0 ? (
        <p className="py-12 text-center text-muted-foreground">No clubs match your search.</p>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {clubs.map((club) => (
            <ClubCard key={club.id} club={club} />
          ))}
        </div>
      )}
    </div>
  );
}
