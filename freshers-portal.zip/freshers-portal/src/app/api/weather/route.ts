import { NextResponse } from 'next/server';
import { getCampusWeather } from '@/lib/weather';

export async function GET() {
  try {
    const weather = await getCampusWeather();
    return NextResponse.json(weather);
  } catch (err) {
    return NextResponse.json({ error: 'Unable to fetch weather' }, { status: 502 });
  }
}
