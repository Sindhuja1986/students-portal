import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { buildAppContext, buildSystemPrompt, getGeminiModel } from '@/lib/gemini';

export const runtime = 'nodejs';

type IncomingMessage = { role: 'user' | 'assistant'; content: string };

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    // @ts-expect-error - id is a custom field added in callbacks
    const userId: string | undefined = session?.user?.id;

    const { messages }: { messages: IncomingMessage[] } = await req.json();
    if (!messages?.length) {
      return new Response('No messages provided', { status: 400 });
    }

    const context = await buildAppContext(userId);
    const systemPrompt = buildSystemPrompt(context);

    const model = getGeminiModel();

    // Gemini expects alternating user/model turns; system context is injected
    // as the first user turn followed by a canned model acknowledgement.
    const history = messages.slice(0, -1).map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    const chat = model.startChat({
      history: [
        { role: 'user', parts: [{ text: systemPrompt }] },
        { role: 'model', parts: [{ text: 'Understood. I will use the live data provided to answer questions about campus events, clubs, faculty, and timetables.' }] },
        ...history,
      ],
    });

    const lastMessage = messages[messages.length - 1].content;
    const result = await chat.sendMessageStream(lastMessage);

    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of result.stream) {
            const text = chunk.text();
            if (text) controller.enqueue(encoder.encode(text));
          }
          controller.close();
        } catch (err) {
          controller.error(err);
        }
      },
    });

    return new Response(stream, {
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  } catch (err) {
    console.error('Chat route error:', err);
    return new Response(
      "Sorry, I'm having trouble right now. Please make sure GEMINI_API_KEY is configured and try again.",
      { status: 500 }
    );
  }
}
