import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const search = searchParams.get('search');
  const category = searchParams.get('category');

  const clubs = await prisma.club.findMany({
    where: {
      ...(category && category !== 'ALL' ? { category } : {}),
      ...(search
        ? {
            OR: [
              { name: { contains: search, mode: 'insensitive' } },
              { description: { contains: search, mode: 'insensitive' } },
            ],
          }
        : {}),
    },
    include: {
      events: {
        where: { startTime: { gte: new Date() } },
        orderBy: { startTime: 'asc' },
        take: 3,
      },
    },
    orderBy: { name: 'asc' },
  });

  return NextResponse.json(clubs);
}

export async function POST(req: Request) {
  const body = await req.json();
  const club = await prisma.club.create({ data: body });
  return NextResponse.json(club, { status: 201 });
}
