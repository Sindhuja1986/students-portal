import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const submissionSchema = z.object({
  type: z.enum(['COURSE', 'HOSTEL', 'LIBRARY']),
  data: z.record(z.any()),
});

async function getUserId() {
  const session = await getServerSession(authOptions);
  // @ts-expect-error - id is a custom field
  return session?.user?.id as string | undefined;
}

export async function GET() {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const submissions = await prisma.registrationSubmission.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
  });

  return NextResponse.json(submissions);
}

export async function POST(req: Request) {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const parsed = submissionSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const submission = await prisma.registrationSubmission.create({
    data: { ...parsed.data, userId },
  });

  return NextResponse.json(submission, { status: 201 });
}
