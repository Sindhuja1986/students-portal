import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  // @ts-expect-error - id is a custom field
  const userId: string | undefined = session?.user?.id;

  if (!userId) {
    return NextResponse.json({ error: 'You must be signed in to register.' }, { status: 401 });
  }

  const event = await prisma.event.findUnique({
    where: { id: params.id },
    include: { _count: { select: { registrations: true } } },
  });

  if (!event) return NextResponse.json({ error: 'Event not found' }, { status: 404 });

  const existing = await prisma.eventRegistration.findUnique({
    where: { eventId_userId: { eventId: params.id, userId } },
  });

  if (existing) {
    return NextResponse.json({ error: 'You are already registered for this event.' }, { status: 409 });
  }

  const isFull = event.capacity != null && event._count.registrations >= event.capacity;

  const registration = await prisma.eventRegistration.create({
    data: {
      eventId: params.id,
      userId,
      status: isFull ? 'WAITLISTED' : 'CONFIRMED',
    },
  });

  return NextResponse.json(registration, { status: 201 });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  // @ts-expect-error - id is a custom field
  const userId: string | undefined = session?.user?.id;

  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  await prisma.eventRegistration.delete({
    where: { eventId_userId: { eventId: params.id, userId } },
  });

  return NextResponse.json({ success: true });
}
