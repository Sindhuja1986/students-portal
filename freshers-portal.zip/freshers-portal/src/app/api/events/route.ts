import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const eventSchema = z.object({
  title: z.string().min(3),
  description: z.string().min(10),
  category: z.string(),
  venue: z.string().min(2),
  startTime: z.string(),
  endTime: z.string(),
  posterUrl: z.string().optional(),
  clubId: z.string().optional(),
  capacity: z.number().optional(),
});

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get('category');
  const clubId = searchParams.get('clubId');
  const search = searchParams.get('search');
  const from = searchParams.get('from');
  const to = searchParams.get('to');

  const events = await prisma.event.findMany({
    where: {
      ...(category && category !== 'ALL' ? { category: category as any } : {}),
      ...(clubId ? { clubId } : {}),
      ...(search
        ? {
            OR: [
              { title: { contains: search, mode: 'insensitive' } },
              { description: { contains: search, mode: 'insensitive' } },
            ],
          }
        : {}),
      ...(from || to
        ? {
            startTime: {
              ...(from ? { gte: new Date(from) } : {}),
              ...(to ? { lte: new Date(to) } : {}),
            },
          }
        : {}),
    },
    include: {
      club: { select: { id: true, name: true } },
      _count: { select: { registrations: true } },
    },
    orderBy: { startTime: 'asc' },
  });

  return NextResponse.json(events);
}

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = eventSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const event = await prisma.event.create({
    data: {
      ...parsed.data,
      category: parsed.data.category as any,
      startTime: new Date(parsed.data.startTime),
      endTime: new Date(parsed.data.endTime),
    },
  });

  return NextResponse.json(event, { status: 201 });
}
