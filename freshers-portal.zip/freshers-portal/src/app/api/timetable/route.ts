import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const entrySchema = z.object({
  day: z.enum(['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY']),
  startTime: z.string(),
  endTime: z.string(),
  courseCode: z.string().min(1),
  courseName: z.string().min(1),
  room: z.string().optional(),
  instructor: z.string().optional(),
  color: z.string().optional(),
});

async function getUserId() {
  const session = await getServerSession(authOptions);
  // @ts-expect-error - id is a custom field
  return session?.user?.id as string | undefined;
}

export async function GET() {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const entries = await prisma.timetableEntry.findMany({
    where: { userId },
    orderBy: [{ day: 'asc' }, { startTime: 'asc' }],
  });

  return NextResponse.json(entries);
}

export async function POST(req: Request) {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const parsed = entrySchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const entry = await prisma.timetableEntry.create({
    data: { ...parsed.data, userId },
  });

  return NextResponse.json(entry, { status: 201 });
}
