import Link from 'next/link';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { WelcomeBanner } from '@/components/dashboard/welcome-banner';
import { WeatherWidget } from '@/components/dashboard/weather-widget';
import { EventsCarousel } from '@/components/dashboard/events-carousel';
import { Card, CardContent } from '@/components/ui/card';
import {
  CalendarDays,
  Users,
  UserSquare2,
  Clock,
  CalendarRange,
  ClipboardList,
  Sparkles,
} from 'lucide-react';

const QUICK_LINKS = [
  { href: '/events', label: 'Campus Events', icon: CalendarDays, color: 'text-brand-blue', bg: 'bg-brand-blue/10' },
  { href: '/clubs', label: 'Clubs & Societies', icon: Users, color: 'text-brand-purple', bg: 'bg-brand-purple/10' },
  { href: '/faculty', label: 'Faculty Directory', icon: UserSquare2, color: 'text-brand-teal', bg: 'bg-brand-teal/10' },
  { href: '/timetable', label: 'My Timetable', icon: Clock, color: 'text-brand-green', bg: 'bg-brand-green/10' },
  { href: '/calendar', label: 'Calendar', icon: CalendarRange, color: 'text-brand-amber', bg: 'bg-brand-amber/10' },
  { href: '/registration', label: 'Registration Hub', icon: ClipboardList, color: 'text-brand-blue', bg: 'bg-brand-blue/10' },
];

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const studentName = session?.user?.name?.split(' ')[0] ?? 'Fresher';

  const now = new Date();
  const upcomingEvents = await prisma.event
    .findMany({
      where: { startTime: { gte: now } },
      orderBy: { startTime: 'asc' },
      take: 8,
    })
    .catch(() => []);

  return (
    <div className="container space-y-8 py-8">
      <WelcomeBanner studentName={studentName} />

      {/* Quick nav */}
      <section>
        <h2 className="mb-3 text-lg font-semibold">Quick Access</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {QUICK_LINKS.map((link) => (
            <Link key={link.href} href={link.href}>
              <Card className="h-full transition-shadow hover:shadow-md">
                <CardContent className="flex flex-col items-center gap-2 p-4 text-center">
                  <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${link.bg}`}>
                    <link.icon className={`h-5 w-5 ${link.color}`} />
                  </div>
                  <span className="text-xs font-medium">{link.label}</span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-3">
        <section className="lg:col-span-2">
          <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold">
            <CalendarDays className="h-5 w-5 text-primary" /> Upcoming Events
          </h2>
          <EventsCarousel
            events={upcomingEvents.map((e) => ({
              id: e.id,
              title: e.title,
              venue: e.venue,
              startTime: e.startTime.toISOString(),
              category: e.category,
            }))}
          />
        </section>

        <section>
          <h2 className="mb-3 text-lg font-semibold">Today's Weather</h2>
          <WeatherWidget />
        </section>
      </div>

      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center gap-2 p-6 text-center sm:flex-row sm:justify-between sm:text-left">
          <div className="flex items-center gap-3">
            <Sparkles className="h-8 w-8 text-primary" />
            <div>
              <p className="font-semibold">Need quick answers?</p>
              <p className="text-sm text-muted-foreground">
                Tap the chat bubble in the corner to ask the AI assistant anything about campus life.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
