const WEATHER_CODES: Record<number, { label: string; icon: string }> = {
  0: { label: 'Clear sky', icon: 'sun' },
  1: { label: 'Mainly clear', icon: 'sun' },
  2: { label: 'Partly cloudy', icon: 'cloud-sun' },
  3: { label: 'Overcast', icon: 'cloud' },
  45: { label: 'Fog', icon: 'cloud-fog' },
  48: { label: 'Depositing rime fog', icon: 'cloud-fog' },
  51: { label: 'Light drizzle', icon: 'cloud-drizzle' },
  53: { label: 'Drizzle', icon: 'cloud-drizzle' },
  55: { label: 'Dense drizzle', icon: 'cloud-drizzle' },
  61: { label: 'Light rain', icon: 'cloud-rain' },
  63: { label: 'Rain', icon: 'cloud-rain' },
  65: { label: 'Heavy rain', icon: 'cloud-rain' },
  71: { label: 'Light snow', icon: 'cloud-snow' },
  80: { label: 'Rain showers', icon: 'cloud-rain-wind' },
  95: { label: 'Thunderstorm', icon: 'cloud-lightning' },
};

export async function getCampusWeather() {
  const lat = process.env.CAMPUS_LAT ?? '13.0827';
  const lon = process.env.CAMPUS_LON ?? '80.2707';
  const name = process.env.CAMPUS_NAME ?? 'Campus';

  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min&timezone=auto`;

  const res = await fetch(url, { next: { revalidate: 1800 } });
  if (!res.ok) throw new Error('Weather fetch failed');
  const data = await res.json();

  const code = data.current?.weather_code ?? 0;
  const condition = WEATHER_CODES[code] ?? { label: 'Unknown', icon: 'cloud' };

  return {
    location: name,
    tempC: Math.round(data.current?.temperature_2m ?? 0),
    humidity: data.current?.relative_humidity_2m ?? null,
    windKph: Math.round(data.current?.wind_speed_10m ?? 0),
    condition: condition.label,
    icon: condition.icon,
    highC: Math.round(data.daily?.temperature_2m_max?.[0] ?? 0),
    lowC: Math.round(data.daily?.temperature_2m_min?.[0] ?? 0),
  };
}
