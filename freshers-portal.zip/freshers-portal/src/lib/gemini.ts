import { GoogleGenerativeAI } from '@google/generative-ai';
import { prisma } from '@/lib/prisma';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY ?? '');

export function getGeminiModel() {
  return genAI.getGenerativeModel({
    model: 'gemini-1.5-flash',
    generationConfig: {
      temperature: 0.4,
      maxOutputTokens: 1024,
    },
  });
}

/**
 * Pulls a compact snapshot of live application data so the model can
 * ground its answers in what's actually in the database, rather than
 * giving generic responses.
 */
export async function buildAppContext(userId?: string) {
  const now = new Date();
  const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  const [upcomingEvents, clubs, faculty, userTimetable] = await Promise.all([
    prisma.event.findMany({
      where: { startTime: { gte: now, lte: weekFromNow } },
      orderBy: { startTime: 'asc' },
      take: 15,
      include: { club: { select: { name: true } } },
    }),
    prisma.club.findMany({ take: 20 }),
    prisma.faculty.findMany({ take: 30 }),
    userId
      ? prisma.timetableEntry.findMany({ where: { userId }, orderBy: [{ day: 'asc' }, { startTime: 'asc' }] })
      : Promise.resolve([]),
  ]);

  const eventsText = upcomingEvents
    .map(
      (e) =>
        `- "${e.title}" (${e.category}) at ${e.venue} on ${e.startTime.toISOString()} ${
          e.club ? `[hosted by ${e.club.name}]` : ''
        }`
    )
    .join('\n');

  const clubsText = clubs
    .map((c) => `- ${c.name} (${c.category}): meets ${c.meetingTime ?? 'TBD'} at ${c.meetingVenue ?? 'TBD'}`)
    .join('\n');

  const facultyText = faculty
    .map((f) => `- ${f.name}, ${f.department} (${f.designation ?? 'Faculty'}), office hours: ${f.officeHours ?? 'N/A'}, email: ${f.email}`)
    .join('\n');

  const timetableText = userTimetable
    .map((t) => `- ${t.day} ${t.startTime}-${t.endTime}: ${t.courseName} (${t.courseCode}) in ${t.room ?? 'TBD'}`)
    .join('\n');

  return `
CURRENT DATE/TIME: ${now.toISOString()}

UPCOMING EVENTS (next 7 days):
${eventsText || 'No events in the next 7 days.'}

CLUBS & SOCIETIES:
${clubsText || 'No club data available.'}

FACULTY DIRECTORY (partial):
${facultyText || 'No faculty data available.'}

${userId ? `THIS STUDENT'S TIMETABLE:\n${timetableText || 'No timetable entries saved yet.'}` : ''}
`.trim();
}

export function buildSystemPrompt(context: string) {
  return `You are the Freshers Portal Assistant, a helpful AI chatbot for new college students.
You have access to LIVE application data below. Always ground your answers in this data instead of
making things up. If the data doesn't contain the answer, say so honestly and suggest where the
student could find it (e.g. "check the Events page" or "contact the department office").

Keep answers concise, friendly, and formatted with markdown (bullet points, bold) where helpful.
When mentioning events, include the date, time, and venue. When mentioning registration, tell the
student to use the "Register" button on the Events page or the Registration Hub.

LIVE APPLICATION DATA:
${context}`;
}
